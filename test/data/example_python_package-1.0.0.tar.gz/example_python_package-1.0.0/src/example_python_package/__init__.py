def hello(who):
    print(f"Hello, {who}!")
